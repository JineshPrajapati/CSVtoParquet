import pyodbc

DATABASE_CONFIG = {
    'server': 'JINESH-PC',
    'database': 'PythonEMS',
    'driver': '{ODBC Driver 17 for SQL Server}'  # Make sure you have the correct ODBC driver installed
}