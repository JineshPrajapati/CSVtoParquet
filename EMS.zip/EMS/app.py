from flask import Flask, render_template, request, redirect, url_for, session,flash
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
import pyodbc
from model import User
from config import DATABASE_CONFIG

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Flask-Login setup
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Enable session protection
login_manager.session_protection = "strong"


# Database connection

def get_db_connection():
    connection = pyodbc.connect(
        f"DRIVER={DATABASE_CONFIG['driver']};"
        f"SERVER={DATABASE_CONFIG['server']};"
        f"DATABASE={DATABASE_CONFIG['database']};"
        f"Trusted_Connection=yes;"
    )
    return connection


@login_manager.user_loader
def load_user(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, password FROM users WHERE id = ?", (user_id,))
    user = cursor.fetchone()
    conn.close()
    if user:
        return User(id=user[0], username=user[1], password=user[2])
    return None

# Handle unauthorized access
@login_manager.unauthorized_handler
def unauthorized():
    flash('You must be logged in to view that page.')
    return redirect(url_for('login', next=request.endpoint))


@app.after_request
def add_header(response):
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0, max-age=0'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '-1'
    return response

# Routes
@app.route('/')
def index():
    return redirect(url_for('login'))  # Redirect to the login page

@app.route('/home')
@login_required  # Protect this route so only logged in users can access it
def home():
    if 'username' in session:
        username = session['username']
        return render_template('home.html', username=username)
    else:
        flash('You are not logged in.', 'error')
        return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id, username, password FROM users WHERE username = ?", (username,))
        user = cursor.fetchone()
        conn.close()
        
        if user and user[2] == password:  # Compare plain text passwords      for hashing check ># and check_password_hash(password,user[2]):
            user_obj = User(id=user[0], username=user[1], password=user[2])
            login_user(user_obj)
            next_page = request.args.get('next')  # Redirect to the next page if available
            session['username'] = username
            return redirect(next_page or url_for('home'))  # Redirect to home page after successful login
        else:
            flash('Invalid credentials')  # Flash error message for invalid credentials
   
   
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.')
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)